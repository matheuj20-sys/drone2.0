# MB Drones — versão com imagens locais

**Importante:** envie a pasta `assets` inteira junto com `index.html` para a raiz do repositório. Não envie apenas o HTML.

## GitHub Pages
1. Extraia o ZIP no computador.
2. No repositório `mb-drones`, faça upload de `index.html` e da pasta `assets` (com os quatro SVGs).
3. Confirme que a estrutura ficou assim:
   - index.html
   - assets/hero-drone.svg
   - assets/eventos.svg
   - assets/rural.svg
   - assets/sobre.svg
4. Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
5. Após publicar, atualize o site com Ctrl+F5.

As imagens ilustrativas agora estão hospedadas junto com a página, sem depender de serviços externos de fotografia.
